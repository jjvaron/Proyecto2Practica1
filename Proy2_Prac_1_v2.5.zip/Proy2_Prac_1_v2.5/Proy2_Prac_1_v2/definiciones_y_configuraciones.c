/* Ruler 1         2         3         4         5         6         7        */
/*
 Declaración de funciones previamente enunciadas en la libreria de
 definiciones y configuraciones

 /* ********************************* Headers ******************************** */

 /* --------------------- Inclusion de librerias estandar -------------------- */
 #include "definiciones_y_configuraciones.h"

 * ******************************** Funciones ******************************* */
 /* ------------------------------ Inicialización ---------------------------- */
   void DyC_Inicie_Puertos()
   {
   // Habilita los pines 16, 15, 14
   DDRB |= (1<<DDB2) | (1<<DDB1) | (1<<DDB0);
   // Habilita los pines 23, 24
   DDRC |= (1<<DDC1) | (1<<DDC0);
   // Habilita los pines 13, 12, 11, 6
   DDRD |= (1<<DDD7) | (1<<DDD6) | (1<<DDD5) | (1<<DDD4);
   }

 /* ---------------------------------- ADC ----------------------------------- */
    //Función Para resetear el ADC
   void DyC_ResetADC()
   {
   	ADCSRA = 0x00;
   	ADMUX  = 0x00;
   }

   //Función Para configurar la inicialización del ADC
   void DyC_Inicie_ADC()
   {
    	// Ajusta el resultado a la derecha Pag. 317
    	ADMUX &= ~(1<<ADLAR);
    	// revisar si la linea de arriba tiene conflicto con el return
    	// de la funcion leaADC (return ADCL | (ADCH << 8);;
      // retorna la temperatura en celsios )

    	// Voltaje de referencia = 1.1 V Pag. 317 Tabla 28-3
    	ADMUX |= (1<<REFS0); // 1
    	ADMUX |= (1<<REFS1); // 1

    	// Ahora se utiliza un divisor de frecuencias para cumplir con
    	// la siguiente condicion 50 kHz < f < 200 kHz �Pag. 308
    	// Divisor de frecuencia = 128 --> 16000 kHz/128 = 125 kHz.
      //Pags. 319, 320 Tabla 28-5
    	ADCSRA |= (1<<ADPS0);   // 1
    	ADCSRA |= (1<<ADPS1);   // 1
    	ADCSRA |= (1<<ADPS2);   // 1

    // Habilitando el sensor de temperatura Pag. 317, 318
    	ADMUX  &=~ (1<<MUX0); // 0
    	ADMUX  &=~ (1<<MUX1); // 0
    	ADMUX  |=  (1<<MUX3); // 1
    }

    //función para extraer lectura de temperatura del ADC
    short DyC_LeaADC()
    {
      ADCSRA |= (1 << ADSC) | (1 << ADEN); // comienza conversi�n ADC
      while (bit_is_set(ADCSRA,ADSC)); // Detect end-of-conversion

      return ADCL | (ADCH << 8);; // retorna la temperatura en celsios
      // revisar si esta ultima línea entra en conflicto con el ADC
    }

    // función para procesar los datos que provee el ADC
    // se busca modificar las varaibles (tempUnidades y tempDecenas)
    // que van a ingresar a las funciones del diplay
    // para modificar estas variables se pasa como referencia un apuntador

    //NOTA: todavia no me convence mucho la forma de manejar las varaibles
    // y de como se ingresan a las funciones, ya que a estas no les entra un
    // apuntador, revisar si se puede hacer una conversión en plan:
    // a = el contenido de lo apuntado
    // y eso se manipula en las varaibles
    // luego, a los apuntadores que si me interesa les meto el valor del
    // resultado de la función
    // en resumen, quiero manipular sacar valores de esta función y quiero
    // modificar mis variables globales
    void DyC_Procese_ADC(int8_t *temperatura,
                        int8_t *tempUnidades,
                        int8_t *tempDecenas)
    {
      short adcval;
      adcval = DyC_LeaADC();
      *temperatura  = convierta_a_Celsius(adcval);
      *tempUnidades = obtenerUnidades(int8_t *temperatura); //diria que no se requiere el apuntador al ingresar
      *tempDecenas  = obtenerDecenas(int8_t *temperatura);
    }


    // las siguientes funciones no llvan DyC_ al inicio ya que son
    // utilizadas dentro de DyC_Procese_ADC y no son llamadas en el main
    // de forma explicita

    //función para convertir a grados celsius y proporcionar un ajuste (offset)
    //de la medición que provee el sensor
    int8_t convierta_a_Celsius(short temp_value)
    {
      /* f(x) = (raw_value - offset) / coeff */
      return int8_t ((temp_value - 324.31)/1.22);
    }

    //función para extraer Unidades
    int8_t obtenerUnidades(int8_t val)
    {
      int8_t modulo;
    	if(val > 0)
      {
    		modulo = val % 10; //extraer unidades/
    	}
    	return modulo;
    }

    //función para extraer Decenas
    int8_t obtenerDecenas(int8_t val)
    {
      int8_t modulo;
    	if(val > 0)
      {
    		modulo = val % 10;
    		val = val/10;  //extraer decenas
    		//modulo = val % 10;//extraer decenas esto prodria estar sobrando
    	}
    	return val;
    }
