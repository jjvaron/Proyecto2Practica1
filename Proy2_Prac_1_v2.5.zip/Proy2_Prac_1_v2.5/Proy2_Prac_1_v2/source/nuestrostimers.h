/* Ruler 1         2         3         4         5         6         7        */
/*
 * nuestrostimers.h
 *
 * Created: 24/09/2020 4:56:36 p. m.
 *  Author: sebas
 */ 

#ifndef NUESTROSTIMERS_H_
#define NUESTROSTIMERS_H_

/* ********************************* Headers ******************************** */

/* --------------------- Inclusion de librerias estandar -------------------- */
#include <avr/io.h>
#include <stdlib.h>
#include <avr/interrupt.h>

//#include <stddef.h>

/* ********************** Definicion de tipos de datos ********************** */

/* ------------------------- Definiciones del timer ------------------------- */
typedef struct Tm_Periodico Tm_Periodico;
#define TM_PER_B_ACTIVO		0x01U
#define TM_PER_B_TC			0x02U
#define TM_Out_B_TC			0x04U

#define	Fclk      1000UL // Frecuencia base en Hz del timer
#define F_CPU 16000000UL // Frecuencia del oscilador externo. 16 MHz

// Estructura de datos
struct Tm_Periodico
{
	unsigned int	contador,// van los conteos temporales por timer multiplo
	                periodo;//hasta donde quiero contar
	unsigned long	timeout;//ac? va un timeout
	unsigned char   banderas; //el primer bit me dice si est? activo este timer el segundo me dice si se da periodo
};

// Funcion para inicializar el Timer 1
void Tm_Inicie_timer(void);

//funciones para  procesar tiempo
void Tm_Procese_tiempo (Tm_Periodico *ctp);

//funciones de tiempos periodicos para timers
void Tm_Inicie_periodico (Tm_Periodico *ctp,unsigned int periodo);
char Tm_Hubo_periodico (Tm_Periodico *ctp);
void Tm_Baje_periodico (Tm_Periodico *ctp);
void Tm_Termine_periodico (Tm_Periodico *ctp);

//funciones de timeout
void Tm_Inicie_timeout (Tm_Periodico *ctp,unsigned int tiempo);
char Tm_Hubo_timeout (Tm_Periodico *ctp);
void Tm_Baje_timeout (Tm_Periodico *ctp);

#endif /* NUESTROSTIMERS_H_ */