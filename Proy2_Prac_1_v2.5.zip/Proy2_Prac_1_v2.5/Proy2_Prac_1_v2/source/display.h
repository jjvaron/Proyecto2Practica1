/* Ruler 1         2         3         4         5         6         7        */
/*
Libreria manejo del display donde se visualiza la temperatura
medida por el micro controlador ATMega328P
*/

/* ********************************* Headers ******************************** */
#ifndef DISPLAYDIGITOS_H_
#define DISPLAYDIGITOS_H_
/* --------------------- Inclusion de librerias estandar -------------------- */
#include <avr/io.h>
#include "definiciones_y_configuraciones.h"

/* ****************************** Definiciones ****************************** */

#define UNIDADES 1U// si el estado esta en este muestro unidades
#define DECENAS  2U// si el estado esta en este muestro decenas
//a las definiciones de arriba, se les ageg� U

/*el transistor que deshabilita el display de unidades esta en el puerto D bit 5*/
/* #define PUERTODISPUNIDADES PORTD No se usa esta definicion */
#define TRANDISPUNIDADES  0b00010000 //PD4

/*el transistor que deshabilita el display de decenas esta en el puerto b bit 2*/
/* #define PUERTOBDISPDECENAS PORTC No se usa esta definicion */
#define TRANDISPDECENAS   0b00000010 //PC1
  
/* ------------------------------- Estructuras ------------------------------ */

  typedef struct D_Display D_Display;
  struct D_Display
  {
    uint8_t tempUnidades;
    uint8_t tempDecenas;
    uint8_t mostrando; // Estado
  };

/* ************************* Prototipos de Funciones ************************ */
/* ----------------------------- Manejo Display  ---------------------------- */
void D_inicie_display (D_Display *disp, uint8_t *temperatura); //*tempUnidades, uint8_t *tempDecenas);
void D_apague_display ();
void D_Inicie_Estado(D_Display *disp);
/* -------------------------------- Display --------------------------------- */

void D_Procese_display (D_Display *disp); //, int8_t valor);  // Descomentar para probar display
// Variable valor usada para probar 7-seg

/* ----------------- Funciones que usan las Look-up tables ------------------ */
uint8_t num2BCDPUERTOB(uint8_t num);
uint8_t num2BCDPUERTOC(uint8_t num);
uint8_t num2BCDPUERTOD(uint8_t num);

#endif /* DISPLAYDIGITOS_H_ */