/* Proy2_Prac_1_v2.c
 *
 * Created: 28/9/2020 07:09:18
 * Author : HewlettPackard
 */ 

/* Ruler 1         2         3         4         5         6         7        */
/*
 Main de atenci�n de eventos por interrupcion
 */

 /* *********** Headers ************ */

 /* --------------------- Inclusion de librerias estandar -------------------- */
 #include <avr/io.h>
 #include <avr/interrupt.h>
 #include <avr/sleep.h>
 #include "nuestrostimers.h"
 #include "definiciones_y_configuraciones.h"
 #include "display.h" 
 #include "UART.h"

// #include <avr/io.h> esta incluci�n de librer�a puede ser redundante


// En nuestra implementacion esta deberia ser un global
// si vamos a trabajar por interrupci�n o deberia estar en el
// espacio de memoria del main.


/* ********** Definiciones ********** */

Tm_Periodico digitos, adc;
D_Display display;
ADC_T conversion;
UART_T Recepcion;
char Transmicion;

//D_Display temperatura;//ya va a estar en celsius
/* Comentado. Ahora solo se usa una variable temperatura
uint8_t tempUnidades;//vamos a guardar el BCD de unidades // Lo manejo de esta forma sin el apuntador
uint8_t tempDecenas;//vamos a guardar el BCD de decenas		
*/
uint8_t temperatura_main = 0;

int main()
{
	// Inicializaciones
	cli(); // Deshabilita interrupciones
	
	// Habilita los pines 16, 15, 14
	DDRB |= 0b00000111; //(1<<DDB2) | (1<<DDB1) | (1<<DDB0);
	// Habilita los pines 23, 24
	DDRC |= 0b0000001; //(1<<DDC1) | (1<<DDC0); // Bit uno cambiado a 0
	// Habilita los pines 13, 12, 11, 6
	DDRD |= 0b11110000; //(1<<DDD7) | (1<<DDD6) | (1<<DDD5) | (1<<DDD4); // Bit cuatro en 1
	
	// Iniciando funciones
	Tm_Inicie_timer(); // Vemos los timers? Si yo lo escuch no se si usted a mi
	/* D_inicie_display(&display, &temperatura_main); //&tempUnidades, &tempDecenas); // & para acceder al espacio de memoria donde se encuentran las variables
	Creo que esta funcion mejor no va aca*/
	
	Tm_Inicie_periodico(&digitos, 8); // Periodo en ms en proteus se observa un perido de 10ms
	Tm_Inicie_periodico(&adc, 1000);    // Periodo en ms en proteus se observa un perido de 1 seg
	
	DyC_ResetADC();
	DyC_Inicie_ADC();
	
	D_Inicie_Estado(&display);
	
	UART_init();
	ConfigurarModo();
	
	sei(); // Habilita interrupciones
	
	
    for(;;) // while(1)  
	{	
		if(Tm_Hubo_periodico(&adc))// condicion de ADC
		{
			/* Esto ira en la interrupcion
			Tm_Procese_tiempo (&adc);
			Tm_Procese_tiempo (&digitos);
			*/
			Tm_Baje_periodico(&adc);//reset de condicion ADC
			DyC_HabiliteADC();
			//UART_write_txt("Periodico_ADC \n\r");
			
			if (conversion.bandera == 0x01) // Similar a <<if(Hubo_Conversion(&bandera_ADC))>>
			{
				//UART_write_txt("Hubo_conversi�n_ADC \n\r");
				DyC_Baje_Conversion(&conversion);
				DyC_DeshabiliteADC();				
				
				//UART_write_udata(&valor);
				//UART_write_data(&tempDecenas,&transmitir);
				//UART_write_data(&tempUnidades,&transmitir);
			}
			TX_DEC(&temperatura_main, &Transmicion);
			TX_UNI(&temperatura_main, &Transmicion);
		}
		// Inicia display despues de haber obtenido un dato del ADC
		D_inicie_display(&display, &temperatura_main);
		if(Tm_Hubo_periodico(&digitos))// condicion de display
		{
			Tm_Baje_periodico(&digitos);//reset de condicion display
			D_Procese_display(&display);
		}
		
		if(Hubo_RX(&Recepcion))
		{
			Baje_RX(&Recepcion);
			FSM_UART(&Recepcion);
		}
	}
}

ISR(TIMER1_COMPA_vect)
{
	Tm_Procese_tiempo (&adc);
	Tm_Procese_tiempo (&digitos);
	
	/* Codigo de antes para probar display
	D_Procese_display(&display, valor);
	valor = valor+1;
	
	// Probar ledes y puertos de los transistores
	//PORTC ^= (1<<PORTC0); //PC0 - G en proteus
	//PORTC |= (1<<PORTC1); //PC1 - BaseTransistor DECENAS // Enciende DECENAS
	//PORTD &=~ (1<<PORTD4); //PD4 - BaseTransistor UNIDADES
	
	if (valor>12)
	{
		// Probar ledes y puertos de los transistores
		//PORTC &=~ (1<<PORTC1); //PC1 - BaseTransistor DECENAS
		//PORTD |= (1<<PORTD4); //PD4 - BaseTransistor UNIDADES // Enciende UNIDADES
		
		valor=0;
	}
	*/
}

ISR(ADC_vect)
{
	DyC_Procese_ADC(&temperatura_main);
	DyC_Hubo_Conversion(&conversion);
}

ISR(USART_RX_vect)
{
	Procese_RX(&Recepcion);
}

ISR(INT0_vect)
{} //SMCR &=~ (1<<SE); // Deshabilita el modo sueno