/* Ruler 1         2         3         4         5         6         7        */
/*
 Declaración de funciones previamente enunciadas en la libreria de
 definiciones y configuraciones
 */

 /* ********************************* Headers ******************************** */

 /* --------------------- Inclusion de librerias estandar -------------------- */
 #include "display.h"
 
 /* ******************************** Funciones ******************************* */
 
 /* ----------------------------- Manejo Display  ---------------------------- */
void D_inicie_display (D_Display *disp, uint8_t *temperatura)
{
	disp->tempUnidades = *temperatura%10;
    disp->tempDecenas  = *temperatura/10;
}
   
// Apaga el display antes de cambiar de numero
void D_apague_display() 
{
	// baja todos los pines definidos en los puertos
	PORTB &= 0x00;
	PORTC &= 0x00; 
	PORTD &= 0x00; 
}
// Esto es para definir el estado inicial
void D_Inicie_Estado(D_Display *disp)
{
	disp->mostrando    = UNIDADES;
}

 /* -------------------------------- Display --------------------------------- */
// Mostrar los numeros en el 7-seg
void D_Procese_display (D_Display *disp) //, int8_t valor)
{
	switch(disp->mostrando)
	{
		case UNIDADES: //mostramos unidades
			D_apague_display();
            //muestre_en_display(valor, UNIDADES);//disp->tempUnidades, UNIDADES);
		    // Puerto en 0 desde simulacion // Puerto en 1 desde protoboard
		    PORTD |= TRANDISPUNIDADES;
		    PORTC &=~ TRANDISPDECENAS;
		    PORTB |= num2BCDPUERTOB(disp->tempUnidades); //valor); // Quito las OR, si las dejo, todos segmentos se encenderian
		    PORTC |= num2BCDPUERTOC(disp->tempUnidades); //valor);
		    PORTD |= num2BCDPUERTOD(disp->tempUnidades); //valor);
		  
            disp->mostrando=DECENAS;// cambiar estado
        break;
	  
        case DECENAS: //mostrar decenas
			D_apague_display();
			//muestre_en_display(valor, DECENAS);
			// Puerto en 0 desde simulacion // Puerto en 1 desde protoboard
			PORTD &=~ TRANDISPUNIDADES; //0b00010000; // Para simulacion
			PORTC |= TRANDISPDECENAS;
			PORTB |= num2BCDPUERTOB(disp->tempDecenas); //valor); // Descomentar para probar display
			PORTC |= num2BCDPUERTOC(disp->tempDecenas); //valor);
			PORTD |= num2BCDPUERTOD(disp->tempDecenas);//valor);
			
            disp->mostrando=UNIDADES;// cambiar estado
	    break;
	  
        default:
            disp->mostrando=DECENAS;
	}
}
 
/* -----------------------------  Look-up tables ----------------------------- */
uint8_t num2BCDPUERTOB(uint8_t num)
{
	//PORB SEG                  XXXXXFAB
	//PORB PIN                  76543210
	uint8_t tablaPuertoB[12] = {0b00000111, //0
							   0b00000001,
							   0b00000011,
							   0b00000011,
							   0b00000101, //4
							   0b00000110,
							   0b00000110,
							   0b00000011, //7
							   0b00000111,
							   0b00000111,
							   0b00000000, // Signo menos -
							   0b00000110};
	  
   if(num>=12||num<0)
        return tablaPuertoB[11];/*en la pos 11 de la tabla esta el error*/
    return tablaPuertoB[num];
 }
 uint8_t num2BCDPUERTOC(uint8_t num)
 {
	 //PORC PIN                 XXXXXX+G // +=DECENAS
	 //PORC PIN                 76543210
	 uint8_t tablaPuertoC[12] = {0b00000000,
	  						    0b00000000,
							    0b00000001,
							    0b00000001,
							    0b00000001,//4
							    0b00000001,
							    0b00000001,
							    0b00000000,// 7
							    0b00000001,
							    0b00000001,
							    0b00000001, // Signo menos -
							    0b00000001};
	  
	if(num>=12||num<0)
		return tablaPuertoC[11];/*en la pos 11 de la tabla esta el error*/
	return tablaPuertoC[num];
 }
  uint8_t num2BCDPUERTOD(uint8_t num)
  {
	 //PORD PIN                CDE-XXXX // -=UNIDADES
	 //PORD PIN                76543210
	 uint8_t tablaPuertoD[12] = {0b11100000,
						        0b10000000,
							    0b01100000,
							    0b11000000,
							    0b10000000,//4
							    0b11000000,
							    0b11100000,
							    0b10000000,//7
							    0b11100000,
							    0b11000000,
							    0b00000000, // Signo menos -
							    0b01100000};
	   
	 if(num>=12||num<0)
		return tablaPuertoD[11];/*en la pos 11 de la tabla esta el error*/
	 return tablaPuertoD[num];
  }