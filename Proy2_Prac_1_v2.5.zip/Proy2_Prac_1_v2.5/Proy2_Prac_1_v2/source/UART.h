/*
 * UART.h
 *
 * Created: 6/10/2020 8:41:42 p. m.
 *  Author: sebas
 */ 

#ifndef UART_H_
#define UART_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>

#include "definiciones_y_configuraciones.h"

#define INICIO '#'
#define DORMIR 'S'
//#define LINEA '\n'
//#define PING 'P'

typedef struct UART_T UART_T;
struct UART_T
{
	unsigned char bandera,
				  dato_serial,
				  fsm;
};

#define s0 0
#define s1 1
//#define s2 2

void UART_init(void);						//funci�n para iniciar el USART AVR as�ncrono, 8 bits, 9600 baudios,
unsigned char UART_read(void);				//funci�n para la recepci�n de caracteres
void UART_write(unsigned char);				//funci�n para la transmisi�n de caracteres
void UART_write_txt(char* cadena);
void UART_write_data(uint8_t *pointer, char *send);

/* void UART_write_udata(uint8_t *pointer); Esta funcion no se usa*/

void Procese_RX(UART_T *comunicacion);
char Hubo_RX(UART_T *comunicacion);
void Baje_RX(UART_T *comunicacion);
void TX_DEC(uint8_t *temperatura, char *dato_tx);
void TX_UNI(uint8_t *temperatura, char *dato_tx);
void Inicie_estado_TX(UART_T *comunicacion);
void FSM_UART(UART_T *ptr_char);
void ConfigurarModo(void);
#endif /* UART_H_ */