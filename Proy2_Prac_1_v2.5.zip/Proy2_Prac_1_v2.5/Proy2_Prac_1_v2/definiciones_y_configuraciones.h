/* Ruler 1         2         3         4         5         6         7        */
/*
Libreria para definiciones y configuraciones iniciales del sistema
cómo la declaración de puertos y funciones del ADC
*/

/* ********************************* Headers ******************************** */
#ifndef DEFINICIONES_Y_CONFIGURACIONES_H_
#define DEFINICIONES_Y_CONFIGURACIONES_H_

/* --------------------- Inclusion de librerias estandar -------------------- */

  #include <avr/io.h>
  #include <stdlib.h>
  
  #include <avr/interrupt.h>
  #include <stdint-gcc.h>

/* ****************************** Definiciones ****************************** */
  #define TIEMPOADC     1000U // tiempo en ms; Se agrega la U para tipo unsigned
  #define TIEMPODISPLAY   10U

/* ------------------------------- Estructuras ------------------------------ */

  // typedef short int8_t; //tipo de dato previamente definido en librería 
  //stdint-gcc.h linea 16 de este archivo

/* ******************************** Funciones ******************************* */
/* ------------------------------ Inicialización ---------------------------- */
  void DyC_Inicie_Puertos();

/* ---------------------------------- ADC ----------------------------------- */
  void DyC_ResetADC();
  void DyC_Inicie_ADC();
  short DyC_LeaADC();// Suponiendo que short es una variable de 16 bits con signo
  void DyC_Procese_ADC(int8_t *temperatura,int8_t *tempUnidades,int8_t *tempDecenas);

  int8_t convierta_a_Celsius(short val);
  int8_t convierta_a_Celsius(short adcval);
  int8_t obtenerUnidades(int8_t *temperatura);
  int8_t obtenerDecenas(int8_t *temperatura);


#endif /* DEFINICIONES_Y_CONFIGURACIONES_H_ */
