v2.3

se hace debug con los leds del display
parece que el segmento G hace blink cada 10 seg, se va a probar cambiar 
la base de tiempo del "adc" a 500.
y sacar el procese tiempo de la atenci�n por interrpci�n.
(tambien se debe comentar la ultima linea de inicie_timers)

------------------
El proyecto compila bien con las librerias de

definiciones_y_configuraciones.h
definiciones_y_configuraciones.c

nuestrostimers.h
nuestrostimers.c

Y EL MAIN (la versi�n anterior no lograba esto) 2.1

v2.2 ya compila, se tuvo un error que ya se arregl� {}
solo se ha probado con las funciones de timers en el main (go, go, go!)

{(sin main, again), hay un error rarito con librer�as
recomiendan cambiar el orden de libcore y libm
https://www.avrfreaks.net/comment/874542#comment-874542
https://forum.arduino.cc/index.php?topic=139780.0
El problema era el main, darling, colocalo la proxima vez, por eso enviaba el 
"error ld returned 1 exit status collect2.exe"
}

Nota: si hay un problema porque no reocnoce las librerias y/o directorios
en projet >> 
	Projet properties >> 
			ToolChain >> AVR/GNU C Compiler
					Directories >> agegar el path donde se encuentran las librerias